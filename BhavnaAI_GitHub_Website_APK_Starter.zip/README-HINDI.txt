BHAVNA AI — GitHub Website + Android APK starter

जरूरी बात:
- यह शुरुआती प्रोजेक्ट है; APK अभी पहले से बना हुआ नहीं है।
- GitHub Pages वेबसाइट के लिए repository Public रखें (GitHub Free पर)।
- वेबसाइट खोलने के लिए root index.html मौजूद है।
- Android APK workflow Gradle build चलाता है; अगर प्रोजेक्ट में Gradle Wrapper/Gradle configuration अधूरी हो, तो Actions में build fail हो सकता है। ऐसी स्थिति में Actions के error को देखकर project config ठीक करनी होगी।
- ऑनलाइन AI API key को HTML में सार्वजनिक repository में न डालें। ऐसा करने पर key कोई भी देख सकता है। सुरक्षित backend/proxy की जरूरत होती है।
- शुरुआती offline जवाब नियम-आधारित हैं, पूरा offline LLM नहीं।
